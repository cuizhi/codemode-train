
#include "sys.h"

/*--------test1a（）宏定义----------------------*/
#define TIME_IDLE        400000  //1s
#define SEND_IDLE        0xaa    //发送空闲
#define SEND_WORK        0xbb    //发送使能

#define SERIAL_OUT_START 0x00    //发送准备
#define SERIAL_OUT_CH1   0x01      //单字符发送状态
#define SERIAL_CHECK_CH1 0x10    //单字符发送完成状态
#define SERIAL_OUT_CH2   0x02
#define SERIAL_CHECK_CH2 0x20
#define SERIAL_OUT_CH3   0x03
#define SERIAL_CHECK_CH3 0x30
#define SERIAL_OUT_CH4   0x04
#define SERIAL_CHECK_CH4 0x40
#define SERIAL_OUT_CH5   0x05
#define SERIAL_CHECK_CH5 0x50
#define SERIAL_OUT_CH6   0x06
#define SERIAL_CHECK_CH6 0x60
#define SERIAL_OUT_CH7   0x07
#define SERIAL_CHECK_CH7 0x70   //字符串单次发送完成状态


/*---------------------------------*/
#define _BV(bit)     (1 << (bit))
#define ABS(__N)     ((__N) < 0 ? -(__N) : (__N))

#define TOP          (0x01FF)



/*! \brief set the 16-level led gradation
 *! \param hwLevel gradation
 *! \return none
 */
static void set_led_gradation(uint16_t hwLevel)
{
    static uint16_t s_hwCounter = 0;
    
    if (hwLevel >= s_hwCounter) {
        LED1_ON();
    } else {
        LED1_OFF();
    }
    
    s_hwCounter++;
    s_hwCounter &= TOP;
}

static void breath_led(void)
{
    static uint16_t s_hwCounter = 0;
    static int16_t s_nGray = (TOP >> 1);
                    
    s_hwCounter++;
    if (!(s_hwCounter & (_BV(10)-1))) {
        s_nGray++; 
        if (s_nGray == TOP) {
            s_nGray = 0;
        }
    }
    
    set_led_gradation(ABS(s_nGray - (TOP >> 1)));
}
/*----------test1a----------------------*/
static void test1(void)
{
    static uint32_t s_wTimeIdle = 0;
    static uint8_t s_chSerialOutChar = SERIAL_OUT_START;  //相当于子状态机
    static uint8_t s_chSendState = SEND_WORK;             //总状态，发送空闲--SEND_IDLE，发送使能SEND_WORK
    
    if(!(s_wTimeIdle % TIME_IDLE)) {
        s_wTimeIdle = 0;
        s_chSendState = SEND_WORK;  //达到约1s，脱离“发送空闲”状态，进入发送使能状态SEND_WORK
    }
    s_wTimeIdle++;
    
    if(SEND_WORK == s_chSendState){
        switch(s_chSerialOutChar){
            //----------Start
            case SERIAL_OUT_START:
                s_chSerialOutChar = SERIAL_OUT_CH1;
                break;
            //----------h
            case SERIAL_OUT_CH1:
                if(serial_out('h')){
                    s_chSerialOutChar = SERIAL_OUT_CH2;
                }else{
                    s_chSerialOutChar = SERIAL_CHECK_CH1;
                }
                break;
            case SERIAL_CHECK_CH1:
                if(USART_GetFlagStatus(USART1,USART_FLAG_TC)){ 
                    s_chSerialOutChar = SERIAL_OUT_CH2;
                }
                break;
            //----------e
            case SERIAL_OUT_CH2:
                if(serial_out('e')){
                    s_chSerialOutChar = SERIAL_OUT_CH3;
                }else{
                    s_chSerialOutChar = SERIAL_CHECK_CH2;
                }
                break;
            case SERIAL_CHECK_CH2:
                if(USART_GetFlagStatus(USART1,USART_FLAG_TC)){
                    s_chSerialOutChar = SERIAL_OUT_CH3;
                }
                break;
            //----------l
            case SERIAL_OUT_CH3:
                if(serial_out('l')){
                    s_chSerialOutChar = SERIAL_OUT_CH4;
                }else{
                    s_chSerialOutChar = SERIAL_CHECK_CH3;
                }
                break;
            case SERIAL_CHECK_CH3:
                if(USART_GetFlagStatus(USART1,USART_FLAG_TC)){
                    s_chSerialOutChar = SERIAL_OUT_CH4;
                }
                break;
            //----------l
            case SERIAL_OUT_CH4:
                if(serial_out('l')){
                    s_chSerialOutChar = SERIAL_OUT_CH5;
                }else{
                    s_chSerialOutChar = SERIAL_CHECK_CH4;
                }
                break;
            case SERIAL_CHECK_CH4:
                if(USART_GetFlagStatus(USART1,USART_FLAG_TC)){
                    s_chSerialOutChar = SERIAL_OUT_CH5;
                }
                break;
            //---------o
            case SERIAL_OUT_CH5:
                if(serial_out('o')){
                    s_chSerialOutChar = SERIAL_OUT_CH6;
                }else{
                    s_chSerialOutChar = SERIAL_CHECK_CH5;
                }
                break;
            case SERIAL_CHECK_CH5:
                if(USART_GetFlagStatus(USART1,USART_FLAG_TC)){
                    s_chSerialOutChar = SERIAL_OUT_CH6;
                }
                break; 
            //---------/r
            case SERIAL_OUT_CH6:
                if(serial_out('\r')){
                    s_chSerialOutChar = SERIAL_OUT_CH7;
                }else{
                    s_chSerialOutChar = SERIAL_CHECK_CH6;
                }
                break;
            case SERIAL_CHECK_CH6:
                if(USART_GetFlagStatus(USART1,USART_FLAG_TC)){
                    s_chSerialOutChar = SERIAL_OUT_CH7;
                }
                break; 
            //---------/n
            case SERIAL_OUT_CH7:
                if(serial_out('\n')){
                    s_chSendState = SEND_IDLE; //字符串发送完成，进入发送空闲状态SEND_IDLE
                }else{
                    s_chSerialOutChar = SERIAL_CHECK_CH7;
                }
                break;
            case SERIAL_CHECK_CH7:
                if(USART_GetFlagStatus(USART1,USART_FLAG_TC)){
                    s_chSendState = SEND_IDLE;
                }
                break;                 
                
            default:
                break;
        }
    }

}

int main(void)
{
    system_init();
    
    while (1) {
        breath_led(); 
        test1();  
    }
}

