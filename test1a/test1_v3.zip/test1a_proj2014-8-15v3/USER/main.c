
#include "sys.h"

/*--------test1a（）宏定义----------------------*/
#define TIME_IDLE        400000  //1s
#define SEND_DISABLE     0xaa    //发送空闲
#define SEND_ENABLE      0xbb    //发送使能

#define SERIAL_OUT_START 0x00    //发送准备
#define SERIAL_OUT_H     0x01    //'h'
#define SERIAL_OUT_O     0x02    //'o'
#define SERIAL_OUT_L1    0x03    //'l'
#define SERIAL_OUT_L2    0x04    //'l'
#define SERIAL_OUT_E     0x05    //'e'
#define SERIAL_OUT_LR    0x06    //'\r'
#define SERIAL_OUT_LN    0x07    //'\n'



/*---------------------------------*/
#define _BV(bit)     (1 << (bit))
#define ABS(__N)     ((__N) < 0 ? -(__N) : (__N))

#define TOP          (0x01FF)



/*! \brief set the 16-level led gradation
 *! \param hwLevel gradation
 *! \return none
 */
static void set_led_gradation(uint16_t hwLevel)
{
    static uint16_t s_hwCounter = 0;
    
    if (hwLevel >= s_hwCounter) {
        LED1_ON();
    } else {
        LED1_OFF();
    }
    
    s_hwCounter++;
    s_hwCounter &= TOP;
}

static void breath_led(void)
{
    static uint16_t s_hwCounter = 0;
    static int16_t s_nGray = (TOP >> 1);
                    
    s_hwCounter++;
    if (!(s_hwCounter & (_BV(10)-1))) {
        s_nGray++; 
        if (s_nGray == TOP) {
            s_nGray = 0;
        }
    }
    
    set_led_gradation(ABS(s_nGray - (TOP >> 1)));
}
/*-------------------test1a----------------------------*/
static void test1(void)
{
    static uint32_t s_wTimeIdle = 0;
    static uint8_t s_chSerialOutCharState = SERIAL_OUT_START;  //相当于子状态机
    static uint8_t s_chSendState = SEND_ENABLE;             //总状态，发送失能--SEND_DISABLE，发送使能SEND_ENABLE
    
    if(SEND_ENABLE == s_chSendState){   
        switch(s_chSerialOutCharState){
            //----------Start
            case SERIAL_OUT_START:
                s_chSerialOutCharState = SERIAL_OUT_H;
                break;
            //----------h
            case SERIAL_OUT_H:
                if(serial_out('h')){
                    s_chSerialOutCharState = SERIAL_OUT_E;
                }
                break;
            //----------e
            case SERIAL_OUT_E:
                if(serial_out('e')){
                    s_chSerialOutCharState = SERIAL_OUT_L1;
                }
                break;
            //----------l
            case SERIAL_OUT_L1:
                if(serial_out('l')){
                    s_chSerialOutCharState = SERIAL_OUT_L2;
                }
                break;
            //----------l
            case SERIAL_OUT_L2:
                if(serial_out('l')){
                    s_chSerialOutCharState = SERIAL_OUT_O;
                }
                break;
            //---------o
            case SERIAL_OUT_O:
                if(serial_out('o')){
                    s_chSerialOutCharState = SERIAL_OUT_LR;
                }
                break; 
            //---------/r
            case SERIAL_OUT_LR:
                if(serial_out('\r')){
                    s_chSerialOutCharState = SERIAL_OUT_LN;
                }
                break; 
            //---------/n
            case SERIAL_OUT_LN:
                if(serial_out('\n')){
                    s_chSerialOutCharState = SERIAL_OUT_START;  //子状态机回复到初始状态
                    
                    s_chSendState = SEND_DISABLE; // 总状态切换statechange : SEND_ENABLE ----------->SEND_DISALBE 
                }
                break;                 
                
            default:
                break;
        }
    }else if(SEND_DISABLE == s_chSendState){
        if(!(s_wTimeIdle % TIME_IDLE)) {
            s_wTimeIdle = 0;
            s_chSendState = SEND_ENABLE;      //count about 1s , 总状态切换statechange : SEND_DISABLE----------->SEND_ENABLE
        }
        s_wTimeIdle++;
    }
}

int main(void)
{
    system_init();
    
    while (1) {
        breath_led(); 
        test1();  
    }
}

