#ifndef __TEST_1A_H__
#define __TEST_1A_H__


void test1a(void); 






#endif