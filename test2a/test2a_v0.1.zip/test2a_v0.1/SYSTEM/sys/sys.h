#ifndef _SYS_H_
#define _SYS_H_

#include "stm32f10x_it.h"

#include "led.h"
#include "key.h"
#include "usart.h"	  

void system_init(void);
#endif
